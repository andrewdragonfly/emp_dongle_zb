
#ifndef UART_HANDLER_H__
#define UART_HANDLER_H__

#include "dev_defines.h"
//#include "data_store.h"

#include "nrf_log.h"
#include "nrf_log_ctrl.h"
#include "nrf_log_default_backends.h"
#include "nrf_error.h"
#include "app_util_platform.h"
#include "app_fifo.h"
#include "app_uart.h"
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include "boards.h"
#include "nrf_gpio.h"
#include "app_error.h"
#include "nrf_delay.h"
#include "nrf.h"
#include "math.h"
#include "bsp.h"
#include "app_timer.h"
#include "nrf_drv_clock.h"

#if defined (UART_PRESENT)
#include "nrf_uart.h"
#endif
#if defined (UARTE_PRESENT)
#include "nrf_uarte.h"
#endif

APP_TIMER_DEF(m_repeated_timer_id);


#define MAX_TEST_DATA_BYTES     (15U)                /**< max number of test bytes to be used for tx and rx. */
#define UART_TX_BUF_SIZE 64                         /**< UART TX buffer size. */
#define UART_RX_BUF_SIZE 64                         /**< UART RX buffer size. */

#define UART_HWFC APP_UART_FLOW_CONTROL_DISABLED


void zigbee_transmit();//function declaration

int8_t buffer_uart_array [100] = {0}; 

uint8_t trans_len_i = 0;
bool uart_set = false, charge_set = false, uart_error = false;
int error_code = 0, eeww_flag = 0, index_step = 0;
uint32_t index_time = 0;//this is the counter for uart tranmissions

struct{
uint32_t time;
uint16_t value;
}m1_log[12], m2_log[12], m3_log[12], m4_log[12], voltage_log[12], load_log[12], coul_log[12],shunt_log[12],charge_log[12],temperature_log[12], ee_log[12], ww_log[12];

struct {
  uint32_t time_val;
  uint32_t m1_val;
  uint32_t m2_val;
  uint32_t m3_val;
  uint32_t m4_val;
  uint32_t sv_val;
  uint32_t cc_val;
  uint32_t tt_val;
  bool     ac_val;
  bool     dc_val;
  bool     error_state_val;
  uint16_t ee_val;
  uint16_t ww_val;
}Zigbee_uart;

struct {
int days;
int seconds;
}rtc_time, time_log[1000];



void uart_error_handle(app_uart_evt_t * p_event)
{
    if (p_event->evt_type == APP_UART_COMMUNICATION_ERROR){
        bsp_board_led_on(2);
        //APP_ERROR_HANDLER(p_event->data.error_communication);
        }
    else if (p_event->evt_type == APP_UART_FIFO_ERROR){
        //APP_ERROR_HANDLER(p_event->data.error_code);
        }
}

void real_time (void * p_context){
rtc_time.seconds ++;
if (rtc_time.seconds >= 86400){
rtc_time.days ++;
rtc_time.seconds = 0;
}
}

void init_real_time(){
ret_code_t error_code;
error_code = app_timer_create(&m_repeated_timer_id,APP_TIMER_MODE_REPEATED,real_time);
}

void log_time (){
      index_time ++; 
      index_step = index_time % 12;
      Zigbee_uart.time_val = index_time;
      time_log[index_time].seconds = rtc_time.seconds;
      time_log[index_time].days = rtc_time.days;
      }

void uart_toggle (){// use this when switching
        while(app_uart_close() != NRF_SUCCESS);
        while(app_uart_flush() != NRF_SUCCESS);
        nrf_delay_ms(100);
}

int convert_stream_val (int index_offset){
  int convert_buffer = 0;
 for (int i = 0; i<6; i++){
    convert_buffer = convert_buffer + (buffer_uart_array[i+index_offset+2]-48)*pow(10,(5-i));
    }
  return convert_buffer;
  }

void bms_uart_builder (){
  
  int index_of_m1 = 0, index_of_m2 = 0, index_of_m3 = 0, index_of_m4 = 0, index_of_cc = 0, index_of_tt = 0, index_of_sv = 0, index_of_ch = 0, index_of_ee = 0, index_of_ww = 0;
  bool error_flag = false, discharge_flag = false, charge_flag = false;
 
  for (int i=0; i<80;i++){
    if (buffer_uart_array[i] == 'M' && buffer_uart_array[i+1] == '1'){index_of_m1 = i;}
    if (buffer_uart_array[i] == 'M' && buffer_uart_array[i+1] == '2'){index_of_m2 = i;}
    if (buffer_uart_array[i] == 'M' && buffer_uart_array[i+1] == '3'){index_of_m3 = i;}
    if (buffer_uart_array[i] == 'M' && buffer_uart_array[i+1] == '4'){index_of_m4 = i;}
    if (buffer_uart_array[i] == 'C' && buffer_uart_array[i+1] == 'C'){index_of_cc = i;}
    if (buffer_uart_array[i] == 'S' && buffer_uart_array[i+1] == 'V'){index_of_sv = i;}
    if (buffer_uart_array[i] == 'T' && buffer_uart_array[i+1] == 'T'){index_of_tt = i;}
    if (buffer_uart_array[i] == 'C' && buffer_uart_array[i+1] == 'M'){
    index_of_ch = i;
    charge_set = true;
    }
    if (buffer_uart_array[i] == 'D' && buffer_uart_array[i+1] == 'C'){
    discharge_flag = true;
    }
    if (buffer_uart_array[i] == 'A' && buffer_uart_array[i+1] == 'C'){
    charge_flag = true;
    }
    
    if (buffer_uart_array[i] == 'E' && buffer_uart_array[i+1] == 'E'){
      index_of_ee = i;
      eeww_flag = 1;
      error_code = buffer_uart_array[i+2] + buffer_uart_array[i+3];
      Zigbee_uart.ee_val = error_code;
      ee_log[index_step].time = index_time; 
      ee_log[index_step].value = error_code;
      error_flag = true;
      }//end if error

    if (buffer_uart_array[i] == 'W' && buffer_uart_array[i+1] == 'W'){
      index_of_ww = i;
      eeww_flag = 2;
      error_code = buffer_uart_array[i+2] + buffer_uart_array[i+3];
      Zigbee_uart.ww_val = error_code;
      ww_log[index_step].time = index_time; 
      ww_log[index_step].value = error_code;
      error_flag = true;
      }//end if warn

      }//end for


      if (error_flag == false){
        log_time ();
        Zigbee_uart.error_state_val = false;
        
        //voltage
        voltage_log [index_step].time = index_time;
        voltage_log [index_step].value = convert_stream_val(index_of_m1) + convert_stream_val(index_of_m2) + convert_stream_val(index_of_m3) + convert_stream_val(index_of_m4);

        m1_log[index_step].time = index_time;
        m2_log[index_step].time = index_time;
        m3_log[index_step].time = index_time;
        m4_log[index_step].time = index_time;
        m1_log[index_step].value = convert_stream_val(index_of_m1);
        m2_log[index_step].value = convert_stream_val(index_of_m2);
        m3_log[index_step].value = convert_stream_val(index_of_m3);
        m4_log[index_step].value = convert_stream_val(index_of_m4);
        //zigbee vars
        Zigbee_uart.m1_val = m1_log[index_step].value;
        Zigbee_uart.m2_val = m2_log[index_step].value;
        Zigbee_uart.m3_val = m3_log[index_step].value;
        Zigbee_uart.m4_val = m3_log[index_step].value;

        //current
        coul_log[index_step].time = index_time;
        coul_log[index_step].value = convert_stream_val(index_of_cc);
        shunt_log[index_step].time = index_time;
        shunt_log[index_step].value = convert_stream_val(index_of_sv);

        //Temperature
        temperature_log [index_step].time = index_time;
        temperature_log [index_step].value = convert_stream_val(index_of_tt);
        Zigbee_uart.tt_val = temperature_log [index_step].value;

        //charging
        charge_log [index_step].time = index_time;
        if (charge_flag == true){
          charge_log [index_step].value = 2;
          Zigbee_uart.ac_val = true;
          Zigbee_uart.dc_val = false;
          } 
        if (discharge_flag == true){
          charge_log [index_step].value = 1;
          Zigbee_uart.dc_val = true;
          Zigbee_uart.ac_val = false;
          }
         
      }//end period send

      if (error_flag == true){
        Zigbee_uart.error_state_val = true;
        eeww_flag = 0;
        trans_len_i = 0;
        }//end error true
      
      }//end fun

void bms_uart_get (app_uart_evt_t * p_event){
uart_set = false;

uint32_t err_code;
switch (p_event->evt_type){
case APP_UART_DATA_READY:
           UNUSED_VARIABLE(app_uart_get(&buffer_uart_array[trans_len_i]));
           trans_len_i++;

 if (buffer_uart_array[trans_len_i - 1] == '\r'){
            nrf_gpio_pin_toggle(LED_2);
                if (trans_len_i > 1){
                    NRF_LOG_HEXDUMP_DEBUG(buffer_uart_array, trans_len_i);            
                    do {
                        uint16_t length = (uint16_t)trans_len_i;
                        if ((err_code != NRF_ERROR_INVALID_STATE) &&
                            (err_code != NRF_ERROR_RESOURCES) &&
                            (err_code != NRF_ERROR_NOT_FOUND))
                        {APP_ERROR_CHECK(err_code);}
                    } while (err_code == NRF_ERROR_RESOURCES);
                }
            }
            uart_set = true;
            if (buffer_uart_array[trans_len_i - 7] == 'E' || buffer_uart_array[trans_len_i - 7] == 'W'){
            uart_error = true;
            break;
            }
            break;

        case APP_UART_COMMUNICATION_ERROR:
            APP_ERROR_HANDLER(p_event->data.error_communication);
            break;

        case APP_UART_FIFO_ERROR:
            APP_ERROR_HANDLER(p_event->data.error_code);
            break;

        default:
            break;
}
}


static void uart_init (void){ //use this when init
NRF_LOG_INFO("UART init");
uint32_t err_code;
    const app_uart_comm_params_t comm_params =
      {
          RX_PIN_NUMBER,
          TX_PIN_NUMBER,
          UART_PIN_DISCONNECTED,
          UART_PIN_DISCONNECTED,
          UART_HWFC,
          false,
#if defined (UART_PRESENT)
NRF_UART_BAUDRATE_115200 
#else
          NRF_UARTE_BAUDRATE_115200 

#endif
      };

    APP_UART_FIFO_INIT(&comm_params,
                       UART_RX_BUF_SIZE,
                       UART_TX_BUF_SIZE,
                       bms_uart_get,
                       APP_IRQ_PRIORITY_LOWEST,
                       err_code);
    APP_ERROR_CHECK(err_code);
}

void uart_send (){// use this when sending 
uint32_t err_code;
 const app_uart_comm_params_t comm_params_external =
      {
          RX2_PIN_NUMBER,
          TX2_PIN_NUMBER,
          UART_PIN_DISCONNECTED,
          UART_PIN_DISCONNECTED,
          UART_HWFC,
          false,
#if defined (UART_PRESENT)
          NRF_UART_BAUDRATE_115200 
#else
          NRF_UARTE_BAUDRATE_115200 
#endif
      };

APP_UART_FIFO_INIT(&comm_params_external,
                         UART_RX_BUF_SIZE,
                         UART_TX_BUF_SIZE,
                         bms_uart_get,
                         //uart_error_handle,
                         APP_IRQ_PRIORITY_LOWEST,
                         err_code);

        APP_ERROR_CHECK(err_code);
}


 void uart_send_array (){
 //while(app_uart_flush() != NRF_SUCCESS);
  if (uart_error == true || (uart_set == true && trans_len_i>=80)){
  bms_uart_builder();
  uart_set = false;
  charge_set = false;
  uart_error = false;
  trans_len_i = 0;
  zigbee_transmit();
  nrf_gpio_pin_toggle(LED_2);
  }

  }


#endif  /* _ UART_HANDLER_H__ */
